# Rooting diagnostics

Genus subtrees: 1046; with an outgroup: 1046; outgroup not a split: 194/1046 (19%).
Rooting recorded in the run but not reproduced here: 0.

## How badly do the failures fail?

Fewest ingroup units to remove for the ingroup to be a split (rogue_in). With two outgroup units these are the ingroup units on the path between them.

| rogue_in | genera |
| --- | --- |
| 1 | 79 |
| 2 | 25 |
| 3 to 5 | 37 |
| more than 5 | 53 |

Rogue units as a share of the genus: median 25%.

## What predicts failure?

Failure rate by quartile of each variable.

**n_in**

| bin | failed |
| --- | --- |
| <= 5 | 37/309 (12%) |
| 5 to 10 | 34/220 (15%) |
| 10 to 25 | 53/260 (20%) |
| > 25 | 70/257 (27%) |

**stem_age**

| bin | failed |
| --- | --- |
| <= 36.5 | 52/263 (20%) |
| 36.5 to 82.3 | 48/262 (18%) |
| 82.3 to 156 | 64/260 (25%) |
| > 156 | 30/261 (11%) |

**mean_in_out**

| bin | failed |
| --- | --- |
| <= 0.199 | 41/262 (16%) |
| 0.199 to 0.233 | 50/262 (19%) |
| 0.233 to 0.272 | 55/261 (21%) |
| > 0.272 | 48/261 (18%) |

**min_in_out**

| bin | failed |
| --- | --- |
| <= 0.164 | 73/262 (28%) |
| 0.164 to 0.196 | 51/262 (19%) |
| 0.196 to 0.231 | 50/261 (19%) |
| > 0.231 | 20/261 (8%) |

**max_in_in**

| bin | failed |
| --- | --- |
| <= 0.174 | 7/262 (3%) |
| 0.174 to 0.251 | 38/262 (15%) |
| 0.251 to 0.315 | 63/261 (24%) |
| > 0.315 | 86/261 (33%) |

**frac_capped_in_out**

| bin | failed |
| --- | --- |
| <= 0 | 194/1046 (19%) |

**min_overlap**

| bin | failed |
| --- | --- |
| <= 480 | 67/264 (25%) |
| 480 to 547 | 44/261 (17%) |
| 547 to 597 | 48/261 (18%) |
| > 597 | 35/260 (13%) |

**min_seq_sites**

| bin | failed |
| --- | --- |
| <= 510 | 55/265 (21%) |
| 510 to 562 | 57/261 (22%) |
| 562 to 607 | 46/261 (18%) |
| > 607 | 36/259 (14%) |

**backbone_status**

| status | failed |
| --- | --- |
| attached_at_mrca | 29/147 (20%) |
| attached_at_taxon | 8/34 (24%) |
| in_synthesis | 157/865 (18%) |

## How good are the fallbacks?

On the genera where the outgroup worked, the ingroup tree was rooted again by midpoint and by MAD, and compared with the outgroup root (same root split) and with the crown age from barcodes and rate and the relative within-genus PD (tree made ultrametric with crown 1).

| | midpoint | MAD |
| --- | --- | --- |
| same root as outgroup | 372/764 (49%) | 417/764 (55%) |
| crown age / outgroup crown | median 0.97 (IQR 0.92 to 1.01); off by more than 25%: 58/764 | median 1.00 (IQR 0.95 to 1.05); off by more than 25%: 50/764 |
| relative PD / outgroup | median 1.01 (IQR 0.99 to 1.05); off by more than 25%: 39/764 | median 1.00 (IQR 0.97 to 1.02); off by more than 25%: 36/764 |

- 3 to 5 units: midpoint 146/184, MAD 152/184
- 6 to 20 units: midpoint 167/353, MAD 195/353
- 21 to more units: midpoint 59/227, MAD 70/227
- stem age <= 39.3 Ma: midpoint 101/193, MAD 108/193
- stem age 39.3 to 83.7 Ma: midpoint 96/190, MAD 109/190
- stem age 83.7 to 163 Ma: midpoint 88/191, MAD 94/191
- stem age > 163 Ma: midpoint 87/190, MAD 106/190

Agreement is not correctness: an outgroup root can pass the test and still be wrong. If agreement falls with stem age, saturation of the outgroup distances is the likely reason.

On the failed genera, after pruning the rogue units and rooting on the outgroup: midpoint agrees in 24/171, MAD in 20/171.

## Would other outgroups or distances help?

Re-run on the failed genera only. 'Rescued': the ingroup is now a split; with a single outgroup unit that is always so. 'Min. violation': fewest units (ingroup or outgroup) on the wrong side of the best root, the error a tolerant rooting rule would accept.

| variant | rescued | of which one outgroup unit | median rogue_in | median min. violation |
| --- | --- | --- | --- | --- |
| out2_longest | 86/194 | 24 | 1 | 1 |
| out5_two_genera | 12/194 | 0 | 3 | 2 |
| out5_spread | 17/194 | 0 | 3 | 2 |
| out10_spread | 12/194 | 0 | 3 | 2 |
| gamma0.5 | 8/194 | 0 | 2 | 1 |

## Is failure a matter of which two units are drawn?

For each genus, 20 random pairs of units from the first sister genus were used as the outgroup instead.

| genera | n | mean share of pairs that work | always | never | sometimes |
| --- | --- | --- | --- | --- | --- |
| rooted on the outgroup in the run | 597 | 0.90 | 402 | 1 | 194 |
| midpoint in the run | 163 | 0.41 | 6 | 9 | 148 |

Expected failure rate with a random pair: 21%.
